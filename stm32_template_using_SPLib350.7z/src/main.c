
#include "stm32f10x.h"

int main(void)
{
	/* 	
	--- Notification for those who migrate from FWLib 2.0.1 ---
	No need for manual SYSCLK configuration remains because  
	"system_stm32f10x.c" initializes SYSCLK instead. 
	*/

	/* Infinite loop */
	while (1)
	{
		
  	}
}
